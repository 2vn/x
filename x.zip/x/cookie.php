<?php
if ($_COOKIE[cuibapvh] != md5('cdcb2k1')) { 
unset($_SESSION[SESS]); }
else
//if (($_COOKIE[cuibapvh] == 'cdcb2k1') AND ($_SESSION[SESS] != true)) { 
//unset($_COOKIE['cuibapvh']); }
$_SESSION[SESS] = true; 
//}