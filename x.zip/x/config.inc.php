<?php
include 'cookie.php';
 if (!defined('ACCESS')) die('Not access'); else $configs = array('username' => 'Admin', 'password' => '1a710202e22a823dd5d1dc12addeea63', 'page_list' => '999999', 'page_file_edit' => '999999', 'page_file_edit_line' => '999999', 'page_database_list_rows' => '20'); ?>